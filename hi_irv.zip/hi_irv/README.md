# Indian Revised Version - Hindi Alignment

STRs:

* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/297 (2TI, JAS)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/313 (ACT, GAL)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/316 (MAT)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/318 (LUK,PHP,COL,1TH,2TH)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/332 (RUT)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/336 (MRK,JHN,ROM,2PE,REV)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/338 (LEV, 2KI)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/339 (1CO,2CO,HEB,1JN,2JN)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/361 (OT books)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/379 (EPH, 1PE)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/406 (TIT)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/415 (OT books)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/424 (ACT)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/425 (GEN, JOS)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/428 (6 OT books)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/431 (4 OT books)
* https://git.door43.org/unfoldingWord/SourceTextRequestForm/issues/461 (11 OT books)
